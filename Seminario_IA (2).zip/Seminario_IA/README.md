#Instruções:

#Para iniciar utilize o comando: python seminario_ia.py

#Para chamar os labirintos utilize comando parecido com esse: Labirintos\medio1.txt
